package com.example.untitled_2553122527

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
